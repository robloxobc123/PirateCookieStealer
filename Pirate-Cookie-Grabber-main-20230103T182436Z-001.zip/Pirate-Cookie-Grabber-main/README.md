# Pirate Cookie Grabber

**I Am not responsible for any malicious use of this program**


Pirate Cookie grabber, The most Over-powered cookie logger in github 🤯 
https://discord.gg/5sRmUjQ2qg (UPDATED INV)

![image](https://user-images.githubusercontent.com/60432696/190850577-26a82220-9774-42c5-beb5-479aa5ee71e1.png)

# Feautres
	🟢Grabs Cookie from (Edge,opera,chrome,etc.)
	🟢Sends Robux Balance to webhook
	🟢Sends Premium Status to webhook
	🟢Sends Roblox Username to webhook
	🟢Sends IP Address to webhook
	🟢Sends RAP to webhook
	🟢Sends Creation date to webhook
	🟢Sends Account age to webhook
	🟣NOT DETECTED BY WINDOWS DEFENDER AND SOME OTHER ANTI VIRUSES
# To Do
	💎Add Token Grabber
	💎Add EXE version Builder
	💎Add Password Stealer
